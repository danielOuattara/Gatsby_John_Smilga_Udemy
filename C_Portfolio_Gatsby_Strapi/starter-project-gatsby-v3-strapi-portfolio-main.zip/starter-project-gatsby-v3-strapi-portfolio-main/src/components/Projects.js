import React from "react"
import Title from "./Title"
import Project from "./Project"
import { Link } from "gatsby"
const Projects = () => {
  return <h2>all projects component</h2>
}

export default Projects
