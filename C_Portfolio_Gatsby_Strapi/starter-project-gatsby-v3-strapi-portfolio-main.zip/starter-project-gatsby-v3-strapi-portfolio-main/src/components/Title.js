import React from "react"

const Title = () => {
  return <h2>title component</h2>
}

export default Title
