import React from "react"
import socialLinks from "../constants/social_links"
const Footer = () => {
  return <h2>footer component</h2>
}

export default Footer
